--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.trip_list DROP CONSTRAINT trip_lists_train_id_fkey;
ALTER TABLE ONLY public.trip_list DROP CONSTRAINT trip_lists_route_id_fkey;
ALTER TABLE ONLY public.station_to_station_block DROP CONSTRAINT sts_block_dep_station_id_fk_station_id;
ALTER TABLE ONLY public.station_to_station_block DROP CONSTRAINT station_to_station_block_destination_station_id_fkey;
ALTER TABLE ONLY public.route_map DROP CONSTRAINT route_map_station_to_station_block_id_fkey;
ALTER TABLE ONLY public.route_map DROP CONSTRAINT route_map_route_id_fkey;
ALTER TABLE ONLY public.bill DROP CONSTRAINT bill_trip_list_id_fkey;
ALTER TABLE ONLY public.bill DROP CONSTRAINT bill_account_id_fkey;
DROP INDEX public.trip_lists_fk_train_id;
DROP INDEX public.trip_list_fk_route_id;
DROP INDEX public.sts_block_dest_station_id_fk;
DROP INDEX public.route_map_fk_sts_block_id;
DROP INDEX public.fki_sts_block_dep_station_id_fk_station_id;
DROP INDEX public."Bills_FK_Trip_List_id";
DROP INDEX public."Bills_FK_Passenger_id";
ALTER TABLE ONLY public.trip_list DROP CONSTRAINT trip_lists_pkey;
ALTER TABLE ONLY public.train DROP CONSTRAINT train_train_number_key;
ALTER TABLE ONLY public.train DROP CONSTRAINT train_pkey;
ALTER TABLE ONLY public.station_to_station_block DROP CONSTRAINT station_to_station_block_pkey;
ALTER TABLE ONLY public.station DROP CONSTRAINT station_pkey;
ALTER TABLE ONLY public.station DROP CONSTRAINT station_name_key;
ALTER TABLE ONLY public.route DROP CONSTRAINT route_pkey;
ALTER TABLE ONLY public.route_map DROP CONSTRAINT route_map_route_id_block_number_in_route_key;
ALTER TABLE ONLY public.route_map DROP CONSTRAINT route_map_pkey;
ALTER TABLE ONLY public.request DROP CONSTRAINT request_pkey;
ALTER TABLE ONLY public.bill DROP CONSTRAINT bill_pkey;
ALTER TABLE ONLY public.bank_detail DROP CONSTRAINT bank_detail_pkey;
ALTER TABLE ONLY public.account DROP CONSTRAINT administrator_pkey;
ALTER TABLE ONLY public.account DROP CONSTRAINT administrator_login_key;
ALTER TABLE public.trip_list ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.train ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.station_to_station_block ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.station ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.route_map ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.route ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bill ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.account ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.trip_lists_id_seq;
DROP SEQUENCE public.trains_id_seq;
DROP SEQUENCE public.station_to_station_blocks_id_seq;
DROP SEQUENCE public.station_id_seq;
DROP VIEW public.search_view;
DROP TABLE public.trip_list;
DROP TABLE public.train;
DROP TABLE public.station_to_station_block;
DROP TABLE public.station;
DROP SEQUENCE public.routes_map_id_seq;
DROP SEQUENCE public.routes_id_seq;
DROP TABLE public.route_map;
DROP TABLE public.route;
DROP SEQUENCE public.requests_id_seq;
DROP TABLE public.request;
DROP SEQUENCE public.bills_id_seq;
DROP TABLE public.bill;
DROP TABLE public.bank_detail;
DROP SEQUENCE public.administrators_id_seq;
DROP TABLE public.account;
DROP TEXT SEARCH DICTIONARY public.bank_details;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: bank_details; Type: TEXT SEARCH DICTIONARY; Schema: public; Owner: h23
--

CREATE TEXT SEARCH DICTIONARY bank_details (
    TEMPLATE = pg_catalog.simple );


ALTER TEXT SEARCH DICTIONARY public.bank_details OWNER TO h23;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE account (
    id integer NOT NULL,
    login character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    first_name character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    access_level character varying(50) NOT NULL
);


ALTER TABLE public.account OWNER TO h23;

--
-- Name: administrators_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE administrators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.administrators_id_seq OWNER TO h23;

--
-- Name: administrators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE administrators_id_seq OWNED BY account.id;


--
-- Name: bank_detail; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE bank_detail (
    currency_of_payment character varying(10) NOT NULL,
    billing_number integer NOT NULL,
    byr_exchange_rate double precision NOT NULL
);


ALTER TABLE public.bank_detail OWNER TO h23;

--
-- Name: bill; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE bill (
    id integer NOT NULL,
    account_id integer NOT NULL,
    trip_list_id integer NOT NULL,
    payment_value double precision NOT NULL,
    is_paid boolean NOT NULL,
    billing_number integer NOT NULL,
    from_block integer NOT NULL,
    to_block integer NOT NULL,
    currency_of_payment character varying(10) NOT NULL,
    creation_date timestamp without time zone
);


ALTER TABLE public.bill OWNER TO h23;

--
-- Name: bills_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE bills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bills_id_seq OWNER TO h23;

--
-- Name: bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE bills_id_seq OWNED BY bill.id;


--
-- Name: request; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE request (
    id integer NOT NULL,
    departure_station character varying(50) NOT NULL,
    destination_station character varying(50) NOT NULL,
    departure_date timestamp without time zone,
    arrival_date timestamp without time zone
);


ALTER TABLE public.request OWNER TO h23;

--
-- Name: requests_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.requests_id_seq OWNER TO h23;

--
-- Name: requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE requests_id_seq OWNED BY request.id;


--
-- Name: route; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE route (
    id integer NOT NULL,
    route_name character varying(150) NOT NULL,
    route_type character varying(10) NOT NULL,
    price_for_kilometer double precision NOT NULL
);


ALTER TABLE public.route OWNER TO h23;

--
-- Name: route_map; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE route_map (
    id integer NOT NULL,
    route_id integer NOT NULL,
    station_to_station_block_id integer NOT NULL,
    block_number_in_route integer NOT NULL,
    block_leave_time time without time zone NOT NULL,
    block_enter_time time without time zone NOT NULL
);


ALTER TABLE public.route_map OWNER TO h23;

--
-- Name: routes_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE routes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.routes_id_seq OWNER TO h23;

--
-- Name: routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE routes_id_seq OWNED BY route.id;


--
-- Name: routes_map_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE routes_map_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.routes_map_id_seq OWNER TO h23;

--
-- Name: routes_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE routes_map_id_seq OWNED BY route_map.id;


--
-- Name: station; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE station (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.station OWNER TO h23;

--
-- Name: station_to_station_block; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE station_to_station_block (
    id integer NOT NULL,
    distance_in_kilometres double precision NOT NULL,
    departure_station_id integer NOT NULL,
    destination_station_id integer NOT NULL
);


ALTER TABLE public.station_to_station_block OWNER TO h23;

--
-- Name: train; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE train (
    id integer NOT NULL,
    train_number character varying(10) NOT NULL,
    passengers_capacity integer NOT NULL
);


ALTER TABLE public.train OWNER TO h23;

--
-- Name: trip_list; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE trip_list (
    id integer NOT NULL,
    train_id integer NOT NULL,
    route_id integer NOT NULL,
    departure_date timestamp without time zone NOT NULL,
    tickets_sold integer NOT NULL
);


ALTER TABLE public.trip_list OWNER TO h23;

--
-- Name: search_view; Type: VIEW; Schema: public; Owner: h23
--

CREATE VIEW search_view AS
 SELECT tl.id AS trip_id,
    r.route_name,
    t.train_number AS train,
    s.name AS from_station,
    s2.name AS to_station,
    r.route_type,
    tl.departure_date,
    rm.block_number_in_route AS block,
    rm.block_enter_time AS enter_at,
    rm.block_leave_time AS leave_at,
    t.passengers_capacity AS places,
    tl.tickets_sold AS sold,
    r.price_for_kilometer AS km_price,
    sts.distance_in_kilometres AS km
   FROM ((((((station_to_station_block sts
     JOIN station s ON ((sts.departure_station_id = s.id)))
     JOIN station s2 ON ((sts.destination_station_id = s2.id)))
     JOIN route_map rm ON ((rm.station_to_station_block_id = sts.id)))
     JOIN route r ON ((rm.route_id = r.id)))
     JOIN trip_list tl ON ((tl.route_id = r.id)))
     JOIN train t ON ((tl.train_id = t.id)))
  ORDER BY s.name, s2.name, r.route_type, tl.departure_date;


ALTER TABLE public.search_view OWNER TO h23;

--
-- Name: station_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE station_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.station_id_seq OWNER TO h23;

--
-- Name: station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE station_id_seq OWNED BY station.id;


--
-- Name: station_to_station_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE station_to_station_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.station_to_station_blocks_id_seq OWNER TO h23;

--
-- Name: station_to_station_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE station_to_station_blocks_id_seq OWNED BY station_to_station_block.id;


--
-- Name: trains_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE trains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trains_id_seq OWNER TO h23;

--
-- Name: trains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE trains_id_seq OWNED BY train.id;


--
-- Name: trip_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE trip_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trip_lists_id_seq OWNER TO h23;

--
-- Name: trip_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE trip_lists_id_seq OWNED BY trip_list.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY account ALTER COLUMN id SET DEFAULT nextval('administrators_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY bill ALTER COLUMN id SET DEFAULT nextval('bills_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY request ALTER COLUMN id SET DEFAULT nextval('requests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY route ALTER COLUMN id SET DEFAULT nextval('routes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY route_map ALTER COLUMN id SET DEFAULT nextval('routes_map_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY station ALTER COLUMN id SET DEFAULT nextval('station_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY station_to_station_block ALTER COLUMN id SET DEFAULT nextval('station_to_station_blocks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY train ALTER COLUMN id SET DEFAULT nextval('trains_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY trip_list ALTER COLUMN id SET DEFAULT nextval('trip_lists_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY account (id, login, password, last_name, first_name, email, access_level) FROM stdin;
\.
COPY account (id, login, password, last_name, first_name, email, access_level) FROM '$$PATH$$/2081.dat';

--
-- Name: administrators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('administrators_id_seq', 10, true);


--
-- Data for Name: bank_detail; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY bank_detail (currency_of_payment, billing_number, byr_exchange_rate) FROM stdin;
\.
COPY bank_detail (currency_of_payment, billing_number, byr_exchange_rate) FROM '$$PATH$$/2096.dat';

--
-- Data for Name: bill; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY bill (id, account_id, trip_list_id, payment_value, is_paid, billing_number, from_block, to_block, currency_of_payment, creation_date) FROM stdin;
\.
COPY bill (id, account_id, trip_list_id, payment_value, is_paid, billing_number, from_block, to_block, currency_of_payment, creation_date) FROM '$$PATH$$/2083.dat';

--
-- Name: bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('bills_id_seq', 33, true);


--
-- Data for Name: request; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY request (id, departure_station, destination_station, departure_date, arrival_date) FROM stdin;
\.
COPY request (id, departure_station, destination_station, departure_date, arrival_date) FROM '$$PATH$$/2085.dat';

--
-- Name: requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('requests_id_seq', 27, true);


--
-- Data for Name: route; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY route (id, route_name, route_type, price_for_kilometer) FROM stdin;
\.
COPY route (id, route_name, route_type, price_for_kilometer) FROM '$$PATH$$/2087.dat';

--
-- Data for Name: route_map; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY route_map (id, route_id, station_to_station_block_id, block_number_in_route, block_leave_time, block_enter_time) FROM stdin;
\.
COPY route_map (id, route_id, station_to_station_block_id, block_number_in_route, block_leave_time, block_enter_time) FROM '$$PATH$$/2078.dat';

--
-- Name: routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('routes_id_seq', 67, true);


--
-- Name: routes_map_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('routes_map_id_seq', 144, true);


--
-- Data for Name: station; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY station (id, name) FROM stdin;
\.
COPY station (id, name) FROM '$$PATH$$/2079.dat';

--
-- Name: station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('station_id_seq', 63, true);


--
-- Data for Name: station_to_station_block; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY station_to_station_block (id, distance_in_kilometres, departure_station_id, destination_station_id) FROM stdin;
\.
COPY station_to_station_block (id, distance_in_kilometres, departure_station_id, destination_station_id) FROM '$$PATH$$/2080.dat';

--
-- Name: station_to_station_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('station_to_station_blocks_id_seq', 97, true);


--
-- Data for Name: train; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY train (id, train_number, passengers_capacity) FROM stdin;
\.
COPY train (id, train_number, passengers_capacity) FROM '$$PATH$$/2090.dat';

--
-- Name: trains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('trains_id_seq', 24, true);


--
-- Data for Name: trip_list; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY trip_list (id, train_id, route_id, departure_date, tickets_sold) FROM stdin;
\.
COPY trip_list (id, train_id, route_id, departure_date, tickets_sold) FROM '$$PATH$$/2091.dat';

--
-- Name: trip_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('trip_lists_id_seq', 81, true);


--
-- Name: administrator_login_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT administrator_login_key UNIQUE (login);


--
-- Name: administrator_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT administrator_pkey PRIMARY KEY (id);


--
-- Name: bank_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY bank_detail
    ADD CONSTRAINT bank_detail_pkey PRIMARY KEY (currency_of_payment);


--
-- Name: bill_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY bill
    ADD CONSTRAINT bill_pkey PRIMARY KEY (id);


--
-- Name: request_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY request
    ADD CONSTRAINT request_pkey PRIMARY KEY (id);


--
-- Name: route_map_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY route_map
    ADD CONSTRAINT route_map_pkey PRIMARY KEY (id);


--
-- Name: route_map_route_id_block_number_in_route_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY route_map
    ADD CONSTRAINT route_map_route_id_block_number_in_route_key UNIQUE (route_id, block_number_in_route);


--
-- Name: route_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY route
    ADD CONSTRAINT route_pkey PRIMARY KEY (id);


--
-- Name: station_name_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY station
    ADD CONSTRAINT station_name_key UNIQUE (name);


--
-- Name: station_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY station
    ADD CONSTRAINT station_pkey PRIMARY KEY (id);


--
-- Name: station_to_station_block_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY station_to_station_block
    ADD CONSTRAINT station_to_station_block_pkey PRIMARY KEY (id);


--
-- Name: train_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY train
    ADD CONSTRAINT train_pkey PRIMARY KEY (id);


--
-- Name: train_train_number_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY train
    ADD CONSTRAINT train_train_number_key UNIQUE (train_number);


--
-- Name: trip_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY trip_list
    ADD CONSTRAINT trip_lists_pkey PRIMARY KEY (id);


--
-- Name: Bills_FK_Passenger_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Bills_FK_Passenger_id" ON bill USING btree (account_id);


--
-- Name: Bills_FK_Trip_List_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Bills_FK_Trip_List_id" ON bill USING btree (trip_list_id);


--
-- Name: fki_sts_block_dep_station_id_fk_station_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX fki_sts_block_dep_station_id_fk_station_id ON station_to_station_block USING btree (departure_station_id);


--
-- Name: route_map_fk_sts_block_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX route_map_fk_sts_block_id ON route_map USING btree (station_to_station_block_id);


--
-- Name: sts_block_dest_station_id_fk; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX sts_block_dest_station_id_fk ON station_to_station_block USING btree (destination_station_id);


--
-- Name: trip_list_fk_route_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX trip_list_fk_route_id ON trip_list USING btree (route_id);


--
-- Name: trip_lists_fk_train_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX trip_lists_fk_train_id ON trip_list USING btree (train_id);


--
-- Name: bill_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY bill
    ADD CONSTRAINT bill_account_id_fkey FOREIGN KEY (account_id) REFERENCES account(id);


--
-- Name: bill_trip_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY bill
    ADD CONSTRAINT bill_trip_list_id_fkey FOREIGN KEY (trip_list_id) REFERENCES trip_list(id);


--
-- Name: route_map_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY route_map
    ADD CONSTRAINT route_map_route_id_fkey FOREIGN KEY (route_id) REFERENCES route(id) ON DELETE CASCADE;


--
-- Name: route_map_station_to_station_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY route_map
    ADD CONSTRAINT route_map_station_to_station_block_id_fkey FOREIGN KEY (station_to_station_block_id) REFERENCES station_to_station_block(id) ON DELETE CASCADE;


--
-- Name: station_to_station_block_destination_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY station_to_station_block
    ADD CONSTRAINT station_to_station_block_destination_station_id_fkey FOREIGN KEY (destination_station_id) REFERENCES station(id) ON DELETE CASCADE;


--
-- Name: sts_block_dep_station_id_fk_station_id; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY station_to_station_block
    ADD CONSTRAINT sts_block_dep_station_id_fk_station_id FOREIGN KEY (departure_station_id) REFERENCES station(id) ON DELETE CASCADE;


--
-- Name: trip_lists_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY trip_list
    ADD CONSTRAINT trip_lists_route_id_fkey FOREIGN KEY (route_id) REFERENCES route(id);


--
-- Name: trip_lists_train_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY trip_list
    ADD CONSTRAINT trip_lists_train_id_fkey FOREIGN KEY (train_id) REFERENCES train(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

