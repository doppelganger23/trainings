--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."Trip_Lists" DROP CONSTRAINT "Trip_Lists_Wagon_id_fkey";
ALTER TABLE ONLY public."Trip_Lists" DROP CONSTRAINT "Trip_Lists_Train_id_fkey";
ALTER TABLE ONLY public."Trip_Lists" DROP CONSTRAINT "Trip_Lists_Route_id_fkey";
ALTER TABLE ONLY public."Routes_Map" DROP CONSTRAINT "Routes_Map_StS_Block_id_fkey";
ALTER TABLE ONLY public."Routes_Map" DROP CONSTRAINT "Routes_Map_Route_id_fkey";
ALTER TABLE ONLY public."Places_In_Wagons" DROP CONSTRAINT "Places_In_Wagons_Wagon_id_fkey";
ALTER TABLE ONLY public."Bills" DROP CONSTRAINT "Bills_Trip_List_id_fkey";
ALTER TABLE ONLY public."Bills" DROP CONSTRAINT "Bills_Passenger_id_fkey";
DROP INDEX public."Trip_Losts_FK_Trains_id";
DROP INDEX public."Trip_Lists_FK_Wagon_id";
DROP INDEX public."Trip_Lists_FK_Route_id";
DROP INDEX public."Routes_Map_FK_StS_Block_id";
DROP INDEX public."Bills_FK_Trip_List_id";
DROP INDEX public."Bills_FK_Passenger_id";
ALTER TABLE ONLY public."Wagons" DROP CONSTRAINT "Wagons_pkey";
ALTER TABLE ONLY public."Trip_Lists" DROP CONSTRAINT "Trip_Lists_pkey";
ALTER TABLE ONLY public."Trains" DROP CONSTRAINT "Trains_pkey";
ALTER TABLE ONLY public."Trains" DROP CONSTRAINT "Trains_Train_Number_key";
ALTER TABLE ONLY public."Station_to_Station_Blocks" DROP CONSTRAINT "Station_to_Station_Blocks_pkey";
ALTER TABLE ONLY public."Routes" DROP CONSTRAINT "Routes_pkey";
ALTER TABLE ONLY public."Routes_Map" DROP CONSTRAINT "Routes_Map_pkey";
ALTER TABLE ONLY public."Routes_Map" DROP CONSTRAINT "Routes_Map_Route_id_Block_Number_In_Route_key";
ALTER TABLE ONLY public."Requests" DROP CONSTRAINT "Requests_pkey";
ALTER TABLE ONLY public."Places_In_Wagons" DROP CONSTRAINT "Places_In_Wagons_pkey";
ALTER TABLE ONLY public."Places_In_Wagons" DROP CONSTRAINT "Places_In_Wagons_Wagon_id_Place_Number_key";
ALTER TABLE ONLY public."Passangers" DROP CONSTRAINT "Passangers_pkey";
ALTER TABLE ONLY public."Bills" DROP CONSTRAINT "Bills_pkey";
ALTER TABLE ONLY public."Bills" DROP CONSTRAINT "Bills_Billing_Number_key";
ALTER TABLE ONLY public."Administrators" DROP CONSTRAINT "Administrators_pkey";
ALTER TABLE ONLY public."Administrators" DROP CONSTRAINT "Administrators_Login_key";
ALTER TABLE public."Wagons" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Trip_Lists" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Trains" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Station_to_Station_Blocks" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Routes_Map" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Routes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Requests" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Places_In_Wagons" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Passangers" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Bills" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Administrators" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public."Wagons_id_seq";
DROP TABLE public."Wagons";
DROP SEQUENCE public."Trip_Lists_id_seq";
DROP TABLE public."Trip_Lists";
DROP SEQUENCE public."Trains_id_seq";
DROP TABLE public."Trains";
DROP SEQUENCE public."Station_to_Station_Blocks_id_seq";
DROP TABLE public."Station_to_Station_Blocks";
DROP SEQUENCE public."Routes_id_seq";
DROP SEQUENCE public."Routes_Map_id_seq";
DROP TABLE public."Routes_Map";
DROP TABLE public."Routes";
DROP SEQUENCE public."Requests_id_seq";
DROP TABLE public."Requests";
DROP SEQUENCE public."Places_In_Wagons_id_seq";
DROP TABLE public."Places_In_Wagons";
DROP SEQUENCE public."Passangers_id_seq";
DROP TABLE public."Passangers";
DROP SEQUENCE public."Bills_id_seq";
DROP TABLE public."Bills";
DROP SEQUENCE public."Administrators_id_seq";
DROP TABLE public."Administrators";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Administrators; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Administrators" (
    id integer NOT NULL,
    "Login" character varying(50) NOT NULL,
    "Password" character varying(50),
    "Access_Level" integer NOT NULL,
    "Last_Name" character varying(50),
    "First_Name" character varying(50)
);


ALTER TABLE public."Administrators" OWNER TO h23;

--
-- Name: Administrators_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Administrators_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Administrators_id_seq" OWNER TO h23;

--
-- Name: Administrators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Administrators_id_seq" OWNED BY "Administrators".id;


--
-- Name: Bills; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Bills" (
    id integer NOT NULL,
    "Passenger_id" integer NOT NULL,
    "Trip_List_id" integer NOT NULL,
    "Payment_Value" money NOT NULL,
    "Billing_Number" character varying(10) NOT NULL,
    "Is_Paid" boolean NOT NULL
);


ALTER TABLE public."Bills" OWNER TO h23;

--
-- Name: Bills_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Bills_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Bills_id_seq" OWNER TO h23;

--
-- Name: Bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Bills_id_seq" OWNED BY "Bills".id;


--
-- Name: Passangers; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Passangers" (
    id integer NOT NULL,
    "Last_Name" character varying(50),
    "First_Name" character varying(50),
    "Passport_Number" character varying(50)
);


ALTER TABLE public."Passangers" OWNER TO h23;

--
-- Name: Passangers_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Passangers_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Passangers_id_seq" OWNER TO h23;

--
-- Name: Passangers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Passangers_id_seq" OWNED BY "Passangers".id;


--
-- Name: Places_In_Wagons; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Places_In_Wagons" (
    id integer NOT NULL,
    "Wagon_id" integer NOT NULL,
    "Place_Number" integer NOT NULL,
    "Is_Lower" boolean NOT NULL,
    "Is_Reserved" boolean NOT NULL
);


ALTER TABLE public."Places_In_Wagons" OWNER TO h23;

--
-- Name: Places_In_Wagons_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Places_In_Wagons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Places_In_Wagons_id_seq" OWNER TO h23;

--
-- Name: Places_In_Wagons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Places_In_Wagons_id_seq" OWNED BY "Places_In_Wagons".id;


--
-- Name: Requests; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Requests" (
    id integer NOT NULL,
    "Departure_Station" character varying(50),
    "Destination_Station" character varying(50),
    "Departure_Date" date,
    "Arrival_Date" date
);


ALTER TABLE public."Requests" OWNER TO h23;

--
-- Name: Requests_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Requests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Requests_id_seq" OWNER TO h23;

--
-- Name: Requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Requests_id_seq" OWNED BY "Requests".id;


--
-- Name: Routes; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Routes" (
    id integer NOT NULL,
    "Route_Name" character varying(150) NOT NULL,
    "Route_Type" character varying(10),
    "Price_Multiplier" double precision NOT NULL
);


ALTER TABLE public."Routes" OWNER TO h23;

--
-- Name: Routes_Map; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Routes_Map" (
    id integer NOT NULL,
    "Route_id" integer NOT NULL,
    "StS_Block_id" integer NOT NULL,
    "Block_Number_In_Route" integer NOT NULL,
    "Stand_Time_In_Minutes" integer NOT NULL
);


ALTER TABLE public."Routes_Map" OWNER TO h23;

--
-- Name: Routes_Map_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Routes_Map_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Routes_Map_id_seq" OWNER TO h23;

--
-- Name: Routes_Map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Routes_Map_id_seq" OWNED BY "Routes_Map".id;


--
-- Name: Routes_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Routes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Routes_id_seq" OWNER TO h23;

--
-- Name: Routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Routes_id_seq" OWNED BY "Routes".id;


--
-- Name: Station_to_Station_Blocks; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Station_to_Station_Blocks" (
    id integer NOT NULL,
    "Departure_Station" character varying(50) NOT NULL,
    "Destination_Station" character varying(50) NOT NULL,
    "Distance_In_Kilometres" double precision NOT NULL
);


ALTER TABLE public."Station_to_Station_Blocks" OWNER TO h23;

--
-- Name: Station_to_Station_Blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Station_to_Station_Blocks_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Station_to_Station_Blocks_id_seq" OWNER TO h23;

--
-- Name: Station_to_Station_Blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Station_to_Station_Blocks_id_seq" OWNED BY "Station_to_Station_Blocks".id;


--
-- Name: Trains; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Trains" (
    id integer NOT NULL,
    "Train_Number" character varying(10) NOT NULL,
    "Average_Path_Speed_In_KM" double precision NOT NULL,
    "Price_Multiplier" double precision NOT NULL
);


ALTER TABLE public."Trains" OWNER TO h23;

--
-- Name: Trains_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Trains_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Trains_id_seq" OWNER TO h23;

--
-- Name: Trains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Trains_id_seq" OWNED BY "Trains".id;


--
-- Name: Trip_Lists; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Trip_Lists" (
    id integer NOT NULL,
    "Train_id" integer NOT NULL,
    "Wagon_id" integer NOT NULL,
    "Route_id" integer NOT NULL,
    "Assigned_Wagon_Number" character varying(10) NOT NULL,
    "Departure_Date" date NOT NULL,
    "Departure_Time" time(6) with time zone NOT NULL
);


ALTER TABLE public."Trip_Lists" OWNER TO h23;

--
-- Name: Trip_Lists_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Trip_Lists_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Trip_Lists_id_seq" OWNER TO h23;

--
-- Name: Trip_Lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Trip_Lists_id_seq" OWNED BY "Trip_Lists".id;


--
-- Name: Wagons; Type: TABLE; Schema: public; Owner: h23; Tablespace: 
--

CREATE TABLE "Wagons" (
    id integer NOT NULL,
    "Wagon_Type" character varying(10) NOT NULL,
    "Price_Multiplier" double precision NOT NULL
);


ALTER TABLE public."Wagons" OWNER TO h23;

--
-- Name: Wagons_id_seq; Type: SEQUENCE; Schema: public; Owner: h23
--

CREATE SEQUENCE "Wagons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Wagons_id_seq" OWNER TO h23;

--
-- Name: Wagons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: h23
--

ALTER SEQUENCE "Wagons_id_seq" OWNED BY "Wagons".id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Administrators" ALTER COLUMN id SET DEFAULT nextval('"Administrators_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Bills" ALTER COLUMN id SET DEFAULT nextval('"Bills_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Passangers" ALTER COLUMN id SET DEFAULT nextval('"Passangers_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Places_In_Wagons" ALTER COLUMN id SET DEFAULT nextval('"Places_In_Wagons_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Requests" ALTER COLUMN id SET DEFAULT nextval('"Requests_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Routes" ALTER COLUMN id SET DEFAULT nextval('"Routes_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Routes_Map" ALTER COLUMN id SET DEFAULT nextval('"Routes_Map_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Station_to_Station_Blocks" ALTER COLUMN id SET DEFAULT nextval('"Station_to_Station_Blocks_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Trains" ALTER COLUMN id SET DEFAULT nextval('"Trains_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Trip_Lists" ALTER COLUMN id SET DEFAULT nextval('"Trip_Lists_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Wagons" ALTER COLUMN id SET DEFAULT nextval('"Wagons_id_seq"'::regclass);


--
-- Data for Name: Administrators; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Administrators" (id, "Login", "Password", "Access_Level", "Last_Name", "First_Name") FROM stdin;
\.
COPY "Administrators" (id, "Login", "Password", "Access_Level", "Last_Name", "First_Name") FROM '$$PATH$$/2105.dat';

--
-- Name: Administrators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Administrators_id_seq"', 1, false);


--
-- Data for Name: Bills; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Bills" (id, "Passenger_id", "Trip_List_id", "Payment_Value", "Billing_Number", "Is_Paid") FROM stdin;
\.
COPY "Bills" (id, "Passenger_id", "Trip_List_id", "Payment_Value", "Billing_Number", "Is_Paid") FROM '$$PATH$$/2103.dat';

--
-- Name: Bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Bills_id_seq"', 1, false);


--
-- Data for Name: Passangers; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Passangers" (id, "Last_Name", "First_Name", "Passport_Number") FROM stdin;
\.
COPY "Passangers" (id, "Last_Name", "First_Name", "Passport_Number") FROM '$$PATH$$/2085.dat';

--
-- Name: Passangers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Passangers_id_seq"', 1, false);


--
-- Data for Name: Places_In_Wagons; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Places_In_Wagons" (id, "Wagon_id", "Place_Number", "Is_Lower", "Is_Reserved") FROM stdin;
\.
COPY "Places_In_Wagons" (id, "Wagon_id", "Place_Number", "Is_Lower", "Is_Reserved") FROM '$$PATH$$/2101.dat';

--
-- Name: Places_In_Wagons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Places_In_Wagons_id_seq"', 1, false);


--
-- Data for Name: Requests; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Requests" (id, "Departure_Station", "Destination_Station", "Departure_Date", "Arrival_Date") FROM stdin;
\.
COPY "Requests" (id, "Departure_Station", "Destination_Station", "Departure_Date", "Arrival_Date") FROM '$$PATH$$/2087.dat';

--
-- Name: Requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Requests_id_seq"', 1, false);


--
-- Data for Name: Routes; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Routes" (id, "Route_Name", "Route_Type", "Price_Multiplier") FROM stdin;
\.
COPY "Routes" (id, "Route_Name", "Route_Type", "Price_Multiplier") FROM '$$PATH$$/2091.dat';

--
-- Data for Name: Routes_Map; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Routes_Map" (id, "Route_id", "StS_Block_id", "Block_Number_In_Route", "Stand_Time_In_Minutes") FROM stdin;
\.
COPY "Routes_Map" (id, "Route_id", "StS_Block_id", "Block_Number_In_Route", "Stand_Time_In_Minutes") FROM '$$PATH$$/2093.dat';

--
-- Name: Routes_Map_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Routes_Map_id_seq"', 1, false);


--
-- Name: Routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Routes_id_seq"', 1, false);


--
-- Data for Name: Station_to_Station_Blocks; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Station_to_Station_Blocks" (id, "Departure_Station", "Destination_Station", "Distance_In_Kilometres") FROM stdin;
\.
COPY "Station_to_Station_Blocks" (id, "Departure_Station", "Destination_Station", "Distance_In_Kilometres") FROM '$$PATH$$/2095.dat';

--
-- Name: Station_to_Station_Blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Station_to_Station_Blocks_id_seq"', 1, false);


--
-- Data for Name: Trains; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Trains" (id, "Train_Number", "Average_Path_Speed_In_KM", "Price_Multiplier") FROM stdin;
\.
COPY "Trains" (id, "Train_Number", "Average_Path_Speed_In_KM", "Price_Multiplier") FROM '$$PATH$$/2097.dat';

--
-- Name: Trains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Trains_id_seq"', 1, false);


--
-- Data for Name: Trip_Lists; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Trip_Lists" (id, "Train_id", "Wagon_id", "Route_id", "Assigned_Wagon_Number", "Departure_Date", "Departure_Time") FROM stdin;
\.
COPY "Trip_Lists" (id, "Train_id", "Wagon_id", "Route_id", "Assigned_Wagon_Number", "Departure_Date", "Departure_Time") FROM '$$PATH$$/2089.dat';

--
-- Name: Trip_Lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Trip_Lists_id_seq"', 1, false);


--
-- Data for Name: Wagons; Type: TABLE DATA; Schema: public; Owner: h23
--

COPY "Wagons" (id, "Wagon_Type", "Price_Multiplier") FROM stdin;
\.
COPY "Wagons" (id, "Wagon_Type", "Price_Multiplier") FROM '$$PATH$$/2099.dat';

--
-- Name: Wagons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: h23
--

SELECT pg_catalog.setval('"Wagons_id_seq"', 1, false);


--
-- Name: Administrators_Login_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Administrators"
    ADD CONSTRAINT "Administrators_Login_key" UNIQUE ("Login");


--
-- Name: Administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Administrators"
    ADD CONSTRAINT "Administrators_pkey" PRIMARY KEY (id);


--
-- Name: Bills_Billing_Number_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Bills"
    ADD CONSTRAINT "Bills_Billing_Number_key" UNIQUE ("Billing_Number");


--
-- Name: Bills_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Bills"
    ADD CONSTRAINT "Bills_pkey" PRIMARY KEY (id);


--
-- Name: Passangers_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Passangers"
    ADD CONSTRAINT "Passangers_pkey" PRIMARY KEY (id);


--
-- Name: Places_In_Wagons_Wagon_id_Place_Number_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Places_In_Wagons"
    ADD CONSTRAINT "Places_In_Wagons_Wagon_id_Place_Number_key" UNIQUE ("Wagon_id", "Place_Number");


--
-- Name: Places_In_Wagons_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Places_In_Wagons"
    ADD CONSTRAINT "Places_In_Wagons_pkey" PRIMARY KEY (id);


--
-- Name: Requests_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Requests"
    ADD CONSTRAINT "Requests_pkey" PRIMARY KEY (id);


--
-- Name: Routes_Map_Route_id_Block_Number_In_Route_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Routes_Map"
    ADD CONSTRAINT "Routes_Map_Route_id_Block_Number_In_Route_key" UNIQUE ("Route_id", "Block_Number_In_Route");


--
-- Name: Routes_Map_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Routes_Map"
    ADD CONSTRAINT "Routes_Map_pkey" PRIMARY KEY (id);


--
-- Name: Routes_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Routes"
    ADD CONSTRAINT "Routes_pkey" PRIMARY KEY (id);


--
-- Name: Station_to_Station_Blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Station_to_Station_Blocks"
    ADD CONSTRAINT "Station_to_Station_Blocks_pkey" PRIMARY KEY (id);


--
-- Name: Trains_Train_Number_key; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Trains"
    ADD CONSTRAINT "Trains_Train_Number_key" UNIQUE ("Train_Number");


--
-- Name: Trains_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Trains"
    ADD CONSTRAINT "Trains_pkey" PRIMARY KEY (id);


--
-- Name: Trip_Lists_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Trip_Lists"
    ADD CONSTRAINT "Trip_Lists_pkey" PRIMARY KEY (id);


--
-- Name: Wagons_pkey; Type: CONSTRAINT; Schema: public; Owner: h23; Tablespace: 
--

ALTER TABLE ONLY "Wagons"
    ADD CONSTRAINT "Wagons_pkey" PRIMARY KEY (id);


--
-- Name: Bills_FK_Passenger_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Bills_FK_Passenger_id" ON "Bills" USING btree ("Passenger_id");


--
-- Name: Bills_FK_Trip_List_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Bills_FK_Trip_List_id" ON "Bills" USING btree ("Trip_List_id");


--
-- Name: Routes_Map_FK_StS_Block_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Routes_Map_FK_StS_Block_id" ON "Routes_Map" USING btree ("StS_Block_id");


--
-- Name: Trip_Lists_FK_Route_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Trip_Lists_FK_Route_id" ON "Trip_Lists" USING btree ("Route_id");


--
-- Name: Trip_Lists_FK_Wagon_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Trip_Lists_FK_Wagon_id" ON "Trip_Lists" USING btree ("Wagon_id");


--
-- Name: Trip_Losts_FK_Trains_id; Type: INDEX; Schema: public; Owner: h23; Tablespace: 
--

CREATE INDEX "Trip_Losts_FK_Trains_id" ON "Trip_Lists" USING btree ("Train_id");


--
-- Name: Bills_Passenger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Bills"
    ADD CONSTRAINT "Bills_Passenger_id_fkey" FOREIGN KEY ("Passenger_id") REFERENCES "Passangers"(id);


--
-- Name: Bills_Trip_List_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Bills"
    ADD CONSTRAINT "Bills_Trip_List_id_fkey" FOREIGN KEY ("Trip_List_id") REFERENCES "Trip_Lists"(id);


--
-- Name: Places_In_Wagons_Wagon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Places_In_Wagons"
    ADD CONSTRAINT "Places_In_Wagons_Wagon_id_fkey" FOREIGN KEY ("Wagon_id") REFERENCES "Wagons"(id);


--
-- Name: Routes_Map_Route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Routes_Map"
    ADD CONSTRAINT "Routes_Map_Route_id_fkey" FOREIGN KEY ("Route_id") REFERENCES "Routes"(id);


--
-- Name: Routes_Map_StS_Block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Routes_Map"
    ADD CONSTRAINT "Routes_Map_StS_Block_id_fkey" FOREIGN KEY ("StS_Block_id") REFERENCES "Station_to_Station_Blocks"(id);


--
-- Name: Trip_Lists_Route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Trip_Lists"
    ADD CONSTRAINT "Trip_Lists_Route_id_fkey" FOREIGN KEY ("Route_id") REFERENCES "Routes"(id);


--
-- Name: Trip_Lists_Train_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Trip_Lists"
    ADD CONSTRAINT "Trip_Lists_Train_id_fkey" FOREIGN KEY ("Train_id") REFERENCES "Trains"(id);


--
-- Name: Trip_Lists_Wagon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: h23
--

ALTER TABLE ONLY "Trip_Lists"
    ADD CONSTRAINT "Trip_Lists_Wagon_id_fkey" FOREIGN KEY ("Wagon_id") REFERENCES "Wagons"(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

